const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { category = 'general', limit = 5 } = await req.json();

    const apiKey = Deno.env.get('INTEGRATIONS_API_KEY');
    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: 'News API key not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Build the API URL with proper parameters
    const newsUrl = `https://app-9he7yko7jz7l-api-W9z3M6eOKQVL.gateway.appmedo.com/v1/news/all?language=en&limit=${limit}${category !== 'general' ? `&categories=${category}` : ''}`;

    const newsResponse = await fetch(newsUrl, {
      headers: {
        'X-Gateway-Authorization': `Bearer ${apiKey}`,
        'Accept': 'application/json',
      },
    });

    if (!newsResponse.ok) {
      const error = await newsResponse.text();
      console.error('News API error:', error);
      return new Response(
        JSON.stringify({ error: 'Failed to fetch news data' }),
        { status: newsResponse.status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const newsData = await newsResponse.json();

    // Extract articles from the response
    const articles = newsData.data || [];

    return new Response(
      JSON.stringify({ articles }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in news function:', error);
    return new Response(
      JSON.stringify({ error: error.message || 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
