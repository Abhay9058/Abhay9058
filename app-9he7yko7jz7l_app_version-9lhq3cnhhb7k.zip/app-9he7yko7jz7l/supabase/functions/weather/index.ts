const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { city, lat, lon, forecast } = await req.json();

    let latitude = lat;
    let longitude = lon;

    // If city is provided, use geocoding to get coordinates
    if (city && !lat && !lon) {
      const geocodeUrl = `https://app-9he7yko7jz7l-api-wL1zlmgJGAlY.gateway.appmedo.com/geo/1.0/direct?q=${encodeURIComponent(city)}&limit=1`;
      const apiKey = Deno.env.get('INTEGRATIONS_API_KEY');
      
      const geocodeResponse = await fetch(geocodeUrl, {
        headers: {
          'X-Gateway-Authorization': `Bearer ${apiKey}`,
          'Accept': 'application/json',
        },
      });

      if (!geocodeResponse.ok) {
        return new Response(
          JSON.stringify({ error: 'City not found' }),
          { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const geocodeData = await geocodeResponse.json();
      if (!geocodeData || geocodeData.length === 0) {
        return new Response(
          JSON.stringify({ error: 'City not found' }),
          { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      latitude = geocodeData[0].lat;
      longitude = geocodeData[0].lon;
    }

    if (!latitude || !longitude) {
      return new Response(
        JSON.stringify({ error: 'Location coordinates are required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const apiKey = Deno.env.get('INTEGRATIONS_API_KEY');
    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: 'Weather API key not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Build the API URL
    let weatherUrl = `https://app-9he7yko7jz7l-api-wL1zlmgJGAlY.gateway.appmedo.com/data/3.0/onecall?lat=${latitude}&lon=${longitude}&units=metric`;
    
    if (!forecast) {
      weatherUrl += '&exclude=minutely,hourly,daily,alerts';
    } else {
      weatherUrl += '&exclude=minutely,alerts';
    }

    const weatherResponse = await fetch(weatherUrl, {
      headers: {
        'X-Gateway-Authorization': `Bearer ${apiKey}`,
        'Accept': 'application/json',
      },
    });

    if (!weatherResponse.ok) {
      const error = await weatherResponse.text();
      console.error('Weather API error:', error);
      return new Response(
        JSON.stringify({ error: 'Failed to fetch weather data' }),
        { status: weatherResponse.status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const weatherData = await weatherResponse.json();

    return new Response(
      JSON.stringify(weatherData),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in weather function:', error);
    return new Response(
      JSON.stringify({ error: error.message || 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
