export interface Option {
  label: string;
  value: string;
  icon?: React.ComponentType<{ className?: string }>;
  withCount?: boolean;
}

export interface Task {
  id: string;
  title: string;
  description?: string;
  completed: boolean;
  created_at: string;
  updated_at: string;
}

export interface Reminder {
  id: string;
  title: string;
  reminder_time: string;
  description?: string;
  completed: boolean;
  created_at: string;
}

export interface ConversationMessage {
  id: string;
  user_message: string;
  assistant_response: string;
  command_type?: string;
  created_at: string;
}

export interface Settings {
  id: string;
  voice_name: string;
  speech_rate: number;
  speech_volume: number;
  auto_speak: boolean;
  created_at: string;
  updated_at: string;
}

export interface WeatherData {
  current: {
    temp: number;
    feels_like: number;
    humidity: number;
    pressure: number;
    weather: Array<{
      main: string;
      description: string;
    }>;
    wind_speed: number;
  };
  daily?: Array<{
    dt: number;
    temp: {
      min: number;
      max: number;
    };
    weather: Array<{
      main: string;
      description: string;
    }>;
  }>;
}

export interface NewsArticle {
  uuid: string;
  title: string;
  description: string;
  url: string;
  image_url?: string;
  published_at: string;
  source: string;
}

export type CommandType = 
  | 'time'
  | 'weather'
  | 'weather-forecast'
  | 'news'
  | 'task'
  | 'reminder'
  | 'calculator'
  | 'unit-conversion'
  | 'joke'
  | 'music'
  | 'search'
  | 'wikipedia'
  | 'chat'
  | 'ai-agent'
  | 'help'
  | 'unknown';

export interface CommandResult {
  type: CommandType;
  response: string;
  data?: unknown;
  streaming?: boolean;
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  image?: string;
  imageMimeType?: string;
  timestamp?: Date;
}

