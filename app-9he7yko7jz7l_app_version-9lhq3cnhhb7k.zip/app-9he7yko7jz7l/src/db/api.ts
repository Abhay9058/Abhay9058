import { supabase } from './supabase';
import type { Task, Reminder, ConversationMessage, Settings } from '@/types/index';

// Tasks API
export const tasksApi = {
  getAll: async (): Promise<Task[]> => {
    const { data, error } = await supabase
      .from('tasks')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  create: async (title: string, description?: string): Promise<Task> => {
    const { data, error } = await supabase
      .from('tasks')
      .insert({ title, description })
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  update: async (id: string, updates: Partial<Task>): Promise<Task> => {
    const { data, error } = await supabase
      .from('tasks')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  delete: async (id: string): Promise<void> => {
    const { error } = await supabase
      .from('tasks')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
  },

  toggleComplete: async (id: string, completed: boolean): Promise<Task> => {
    const { data, error } = await supabase
      .from('tasks')
      .update({ completed, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  }
};

// Reminders API
export const remindersApi = {
  getAll: async (): Promise<Reminder[]> => {
    const { data, error } = await supabase
      .from('reminders')
      .select('*')
      .order('reminder_time', { ascending: true });
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  create: async (title: string, reminderTime: string, description?: string): Promise<Reminder> => {
    const { data, error } = await supabase
      .from('reminders')
      .insert({ title, reminder_time: reminderTime, description })
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  delete: async (id: string): Promise<void> => {
    const { error } = await supabase
      .from('reminders')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
  },

  markComplete: async (id: string): Promise<Reminder> => {
    const { data, error } = await supabase
      .from('reminders')
      .update({ completed: true })
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  }
};

// Conversation History API
export const conversationApi = {
  getRecent: async (limit = 50): Promise<ConversationMessage[]> => {
    const { data, error } = await supabase
      .from('conversation_history')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(limit);
    
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  add: async (userMessage: string, assistantResponse: string, commandType?: string): Promise<ConversationMessage> => {
    const { data, error } = await supabase
      .from('conversation_history')
      .insert({ 
        user_message: userMessage, 
        assistant_response: assistantResponse,
        command_type: commandType 
      })
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  clear: async (): Promise<void> => {
    const { error } = await supabase
      .from('conversation_history')
      .delete()
      .neq('id', '00000000-0000-0000-0000-000000000000');
    
    if (error) throw error;
  }
};

// Settings API
export const settingsApi = {
  get: async (): Promise<Settings | null> => {
    const { data, error } = await supabase
      .from('settings')
      .select('*')
      .limit(1)
      .maybeSingle();
    
    if (error) throw error;
    return data;
  },

  update: async (updates: Partial<Settings>): Promise<Settings> => {
    const current = await settingsApi.get();
    
    if (!current) {
      const { data, error } = await supabase
        .from('settings')
        .insert(updates)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    }

    const { data, error } = await supabase
      .from('settings')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', current.id)
      .select()
      .single();
    
    if (error) throw error;
    return data;
  }
};

// Edge Functions API
export const edgeFunctionsApi = {
  chatGPT: async (message: string): Promise<string> => {
    const { data, error } = await supabase.functions.invoke('chatgpt', {
      body: { message }
    });

    if (error) throw error;
    return data.response;
  },

  geminiChat: async (messages: any[], systemPrompt?: string): Promise<ReadableStream> => {
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
    
    const response = await fetch(`${supabaseUrl}/functions/v1/gemini-chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${supabaseAnonKey}`,
      },
      body: JSON.stringify({ messages, systemPrompt })
    });

    if (!response.ok) {
      throw new Error('Failed to get AI response');
    }

    if (!response.body) {
      throw new Error('No response body');
    }

    return response.body;
  },

  getWeather: async (city?: string, lat?: number, lon?: number, forecast = false): Promise<any> => {
    const { data, error } = await supabase.functions.invoke('weather', {
      body: { city, lat, lon, forecast }
    });

    if (error) throw error;
    return data;
  },

  getNews: async (category = 'general', limit = 5): Promise<any> => {
    const { data, error } = await supabase.functions.invoke('news', {
      body: { category, limit }
    });

    if (error) throw error;
    return data;
  }
};
