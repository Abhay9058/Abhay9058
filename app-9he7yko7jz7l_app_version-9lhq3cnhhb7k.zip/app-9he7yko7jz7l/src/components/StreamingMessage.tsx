import { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';

interface StreamingMessageProps {
  content: string;
  isComplete: boolean;
}

export function StreamingMessage({ content, isComplete }: StreamingMessageProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.textContent = content;
    }
  }, [content]);

  return (
    <div className="relative">
      <motion.div 
        ref={containerRef}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-sm whitespace-pre-wrap"
      />
      {!isComplete && (
        <motion.span 
          animate={{ opacity: [1, 0, 1] }}
          transition={{ duration: 0.8, repeat: Number.POSITIVE_INFINITY }}
          className="inline-block w-2 h-4 ml-1 bg-primary"
        />
      )}
    </div>
  );
}
