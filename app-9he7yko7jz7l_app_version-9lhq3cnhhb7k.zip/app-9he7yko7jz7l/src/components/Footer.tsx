import { motion } from 'framer-motion';

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <motion.footer
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, delay: 1 }}
      className="relative z-10 py-6 mt-12 border-t border-primary/20"
    >
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <motion.div
            className="flex items-center gap-2"
            whileHover={{ scale: 1.05 }}
          >
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-secondary celestial-glow flex items-center justify-center">
              <span className="text-xs font-bold text-background">EC</span>
            </div>
            <span className="text-sm font-medium text-primary">ETERNAL CORE AI</span>
          </motion.div>

          <div className="text-center text-sm text-muted-foreground">
            <p>© {currentYear} ETERNAL CORE AI. All rights reserved.</p>
          </div>

          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <motion.a
              href="#"
              className="hover:text-primary transition-colors"
              whileHover={{ scale: 1.1 }}
            >
              Privacy
            </motion.a>
            <span>•</span>
            <motion.a
              href="#"
              className="hover:text-primary transition-colors"
              whileHover={{ scale: 1.1 }}
            >
              Terms
            </motion.a>
          </div>
        </div>
      </div>
    </motion.footer>
  );
}
