import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

export function AnimatedBackground() {
  const [particles, setParticles] = useState<Array<{ id: number; size: number; left: string; delay: number }>>([]);

  useEffect(() => {
    const particleCount = 30;
    const newParticles = Array.from({ length: particleCount }, (_, i) => ({
      id: i,
      size: Math.random() * 80 + 40,
      left: `${Math.random() * 100}%`,
      delay: Math.random() * 20
    }));
    setParticles(newParticles);
  }, []);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
      {/* Dark mystical gradient background */}
      <div className="absolute inset-0 bg-[#0a0e1a]" />
      
      {/* Animated celestial images with higher opacity */}
      <motion.div
        className="absolute inset-0 opacity-30"
        animate={{
          scale: [1, 1.05, 1],
          opacity: [0.3, 0.35, 0.3],
        }}
        transition={{
          duration: 15,
          repeat: Number.POSITIVE_INFINITY,
          ease: "easeInOut"
        }}
      >
        <img 
          src="https://miaoda-conversation-file.s3cdn.medo.dev/user-7vtjxwkihq0w/conv-9he7yko7jz7k/20260208/file-9hharpdplse8.jpg"
          alt=""
          className="w-full h-full object-cover"
        />
      </motion.div>

      <motion.div
        className="absolute inset-0 opacity-25"
        animate={{
          scale: [1, 1.08, 1],
          opacity: [0.25, 0.3, 0.25],
        }}
        transition={{
          duration: 18,
          repeat: Number.POSITIVE_INFINITY,
          ease: "easeInOut",
          delay: 2
        }}
      >
        <img 
          src="https://miaoda-conversation-file.s3cdn.medo.dev/user-7vtjxwkihq0w/conv-9he7yko7jz7k/20260208/file-9hharpdplfr4.jpg"
          alt=""
          className="w-full h-full object-cover"
        />
      </motion.div>

      {/* Geometric pattern overlay */}
      <div className="absolute inset-0 geometric-pattern" />
      
      {/* Floating particles with cyan glow */}
      {particles.map((particle) => (
        <div
          key={particle.id}
          className="particle"
          style={{
            width: `${particle.size}px`,
            height: `${particle.size}px`,
            left: particle.left,
            top: '100%',
            background: `radial-gradient(circle, rgba(195, 255, 255, 0.4), rgba(100, 200, 255, 0.2), transparent)`,
            animationDelay: `${particle.delay}s`,
            animationDuration: `${20 + Math.random() * 15}s`
          }}
        />
      ))}

      {/* Mystical glowing orbs with higher visibility */}
      <motion.div 
        className="mystical-orb"
        style={{
          top: '20%',
          left: '15%',
          background: 'radial-gradient(circle, rgba(195, 255, 255, 0.4), transparent)'
        }}
        animate={{
          x: [0, 100, 0],
          y: [0, -80, 0],
          scale: [1, 1.2, 1],
        }}
        transition={{
          duration: 25,
          repeat: Number.POSITIVE_INFINITY,
          ease: "easeInOut"
        }}
      />
      
      <motion.div 
        className="mystical-orb"
        style={{
          bottom: '25%',
          right: '20%',
          background: 'radial-gradient(circle, rgba(150, 200, 255, 0.35), transparent)'
        }}
        animate={{
          x: [0, -120, 0],
          y: [0, 60, 0],
          scale: [1, 1.15, 1],
        }}
        transition={{
          duration: 22,
          repeat: Number.POSITIVE_INFINITY,
          ease: "easeInOut",
          delay: 3
        }}
      />
      
      <motion.div 
        className="mystical-orb"
        style={{
          top: '50%',
          right: '30%',
          background: 'radial-gradient(circle, rgba(180, 220, 255, 0.3), transparent)'
        }}
        animate={{
          x: [0, 80, 0],
          y: [0, -100, 0],
          scale: [1, 1.3, 1],
        }}
        transition={{
          duration: 28,
          repeat: Number.POSITIVE_INFINITY,
          ease: "easeInOut",
          delay: 5
        }}
      />

      {/* Ethereal light beams */}
      <div className="absolute top-0 left-1/4 w-px h-full bg-gradient-to-b from-transparent via-cyan-500/10 to-transparent animate-pulse" />
      <div className="absolute top-0 right-1/3 w-px h-full bg-gradient-to-b from-transparent via-blue-400/10 to-transparent animate-pulse" style={{ animationDelay: '2s' }} />
    </div>
  );
}
