import { tasksApi, remindersApi, edgeFunctionsApi } from '@/db/api';
import { calculator, unitConverter, timeUtils, jokeUtils, wikipediaUtils, urlUtils } from './utils';
import type { CommandResult, CommandType } from '@/types/index';

export class CommandProcessor {
  async process(input: string): Promise<CommandResult> {
    const lowerInput = input.toLowerCase().trim();

    // Time commands
    if (this.matchesPattern(lowerInput, ['time', 'what time', 'current time', 'clock'])) {
      return {
        type: 'time',
        response: `The current time is ${timeUtils.getCurrentTime()}.`
      };
    }

    // Date commands
    if (this.matchesPattern(lowerInput, ['date', 'what date', 'today', 'what day'])) {
      return {
        type: 'time',
        response: `Today is ${timeUtils.getCurrentDate()}.`
      };
    }

    // Weather commands
    if (this.matchesPattern(lowerInput, ['weather', 'temperature', 'forecast'])) {
      const isForecast = lowerInput.includes('forecast');
      const city = this.extractCity(lowerInput);
      
      try {
        const weatherData = await edgeFunctionsApi.getWeather(city || 'London', undefined, undefined, isForecast);
        
        if (isForecast && weatherData.daily) {
          const forecast = weatherData.daily.slice(0, 3).map((day: any) => {
            const date = new Date(day.dt * 1000).toLocaleDateString('en-US', { weekday: 'short' });
            return `${date}: ${Math.round(day.temp.max)}°C/${Math.round(day.temp.min)}°C - ${day.weather[0].description}`;
          }).join(', ');
          
          return {
            type: 'weather-forecast',
            response: `Weather forecast for ${city || 'London'}: ${forecast}`,
            data: weatherData
          };
        }
        
        const temp = Math.round(weatherData.current.temp);
        const description = weatherData.current.weather[0].description;
        const feelsLike = Math.round(weatherData.current.feels_like);
        
        return {
          type: 'weather',
          response: `The weather in ${city || 'London'} is ${description} with a temperature of ${temp}°C, feels like ${feelsLike}°C.`,
          data: weatherData
        };
      } catch (error) {
        return {
          type: 'weather',
          response: `I couldn't fetch the weather information. ${error instanceof Error ? error.message : 'Please try again.'}`
        };
      }
    }

    // News commands
    if (this.matchesPattern(lowerInput, ['news', 'headlines', 'latest news'])) {
      const category = this.extractNewsCategory(lowerInput);
      
      try {
        const newsData = await edgeFunctionsApi.getNews(category, 5);
        const articles = newsData.articles.slice(0, 3);
        
        if (articles.length === 0) {
          return {
            type: 'news',
            response: 'No news articles found at the moment.'
          };
        }
        
        const headlines = articles.map((article: any, index: number) => 
          `${index + 1}. ${article.title}`
        ).join('. ');
        
        return {
          type: 'news',
          response: `Here are the latest ${category} headlines: ${headlines}`,
          data: newsData
        };
      } catch (error) {
        return {
          type: 'news',
          response: `I couldn't fetch the news. ${error instanceof Error ? error.message : 'Please try again.'}`
        };
      }
    }

    // Task commands
    if (this.matchesPattern(lowerInput, ['add task', 'create task', 'new task', 'task'])) {
      const taskTitle = this.extractTaskTitle(lowerInput);
      
      if (!taskTitle) {
        return {
          type: 'task',
          response: 'Please specify what task you want to add.'
        };
      }
      
      try {
        await tasksApi.create(taskTitle);
        return {
          type: 'task',
          response: `Task "${taskTitle}" has been added to your list.`
        };
      } catch (error) {
        return {
          type: 'task',
          response: 'Failed to add the task. Please try again.'
        };
      }
    }

    // List tasks
    if (this.matchesPattern(lowerInput, ['list tasks', 'show tasks', 'my tasks', 'view tasks'])) {
      try {
        const tasks = await tasksApi.getAll();
        const incompleteTasks = tasks.filter(t => !t.completed);
        
        if (incompleteTasks.length === 0) {
          return {
            type: 'task',
            response: 'You have no pending tasks.'
          };
        }
        
        const taskList = incompleteTasks.slice(0, 5).map((task, index) => 
          `${index + 1}. ${task.title}`
        ).join(', ');
        
        return {
          type: 'task',
          response: `Your tasks: ${taskList}`,
          data: tasks
        };
      } catch (error) {
        return {
          type: 'task',
          response: 'Failed to retrieve tasks.'
        };
      }
    }

    // Reminder commands
    if (this.matchesPattern(lowerInput, ['remind me', 'set reminder', 'reminder'])) {
      const reminderText = this.extractReminderText(lowerInput);
      const timeText = this.extractReminderTime(lowerInput);
      
      if (!reminderText || !timeText) {
        return {
          type: 'reminder',
          response: 'Please specify what to remind you about and when.'
        };
      }
      
      const reminderTime = timeUtils.parseReminderTime(timeText);
      
      if (!reminderTime) {
        return {
          type: 'reminder',
          response: 'I couldn\'t understand the time. Try saying "in 30 minutes" or "in 2 hours".'
        };
      }
      
      try {
        await remindersApi.create(reminderText, reminderTime.toISOString());
        return {
          type: 'reminder',
          response: `I'll remind you about "${reminderText}" at ${reminderTime.toLocaleTimeString()}.`
        };
      } catch (error) {
        return {
          type: 'reminder',
          response: 'Failed to set the reminder. Please try again.'
        };
      }
    }

    // Calculator commands
    if (this.matchesPattern(lowerInput, ['calculate', 'compute', 'what is', 'solve']) && this.containsMath(lowerInput)) {
      const expression = this.extractMathExpression(lowerInput);
      const result = calculator.evaluate(expression);
      
      return {
        type: 'calculator',
        response: `The result is ${result}.`
      };
    }

    // Unit conversion
    if (this.matchesPattern(lowerInput, ['convert', 'conversion'])) {
      const conversion = this.extractConversion(lowerInput);
      
      if (!conversion) {
        return {
          type: 'unit-conversion',
          response: 'Please specify what you want to convert, for example: "convert 5 miles to kilometers".'
        };
      }
      
      const result = unitConverter.convert(conversion.value, conversion.from, conversion.to);
      
      return {
        type: 'unit-conversion',
        response: `${conversion.value} ${conversion.from} is ${result} ${conversion.to}.`
      };
    }

    // Joke commands
    if (this.matchesPattern(lowerInput, ['joke', 'tell me a joke', 'make me laugh', 'funny'])) {
      return {
        type: 'joke',
        response: jokeUtils.getRandomJoke()
      };
    }

    // Music/YouTube commands
    if (this.matchesPattern(lowerInput, ['play', 'music', 'song', 'youtube'])) {
      const query = this.extractSearchQuery(lowerInput, ['play', 'music', 'song', 'youtube']);
      urlUtils.openYouTube(query);
      
      return {
        type: 'music',
        response: query 
          ? `Opening YouTube to play "${query}".`
          : 'Opening YouTube for you.'
      };
    }

    // Search commands
    if (this.matchesPattern(lowerInput, ['search', 'google', 'look up', 'find'])) {
      const query = this.extractSearchQuery(lowerInput, ['search', 'google', 'look up', 'find', 'for']);
      urlUtils.openGoogle(query);
      
      return {
        type: 'search',
        response: query 
          ? `Searching Google for "${query}".`
          : 'Opening Google for you.'
      };
    }

    // Wikipedia commands
    if (this.matchesPattern(lowerInput, ['wikipedia', 'wiki', 'tell me about', 'who is', 'what is'])) {
      const query = this.extractSearchQuery(lowerInput, ['wikipedia', 'wiki', 'tell me about', 'who is', 'what is']);
      
      if (!query) {
        return {
          type: 'wikipedia',
          response: 'What would you like to know about?'
        };
      }
      
      try {
        const summary = await wikipediaUtils.search(query);
        return {
          type: 'wikipedia',
          response: summary
        };
      } catch (error) {
        return {
          type: 'wikipedia',
          response: `I couldn't find information about "${query}".`
        };
      }
    }

    // Help commands
    if (this.matchesPattern(lowerInput, ['help', 'what can you do', 'commands', 'capabilities'])) {
      return {
        type: 'help',
        response: 'I can help you with: checking time, weather forecasts, news updates, managing tasks and reminders, calculations, unit conversions, telling jokes, playing music, web searches, and answering questions. Just ask me!'
      };
    }

    // Default: Use ChatGPT for conversational responses
    try {
      const response = await edgeFunctionsApi.chatGPT(input);
      return {
        type: 'chat',
        response
      };
    } catch (error) {
      return {
        type: 'unknown',
        response: 'I\'m not sure how to help with that. Try asking me about the time, weather, news, or say "help" to see what I can do.'
      };
    }
  }

  // Check if input should use AI agent (streaming)
  shouldUseAIAgent(input: string): boolean {
    const lowerInput = input.toLowerCase();
    
    // Use AI agent for conversational queries
    const conversationalPatterns = [
      'tell me about',
      'explain',
      'why',
      'how',
      'what do you think',
      'can you help',
      'i need',
      'describe',
      'compare',
      'difference between',
      'recommend',
      'suggest',
      'opinion',
      'advice'
    ];

    // Don't use AI agent for specific commands
    const commandPatterns = [
      'add task',
      'create task',
      'remind me',
      'set reminder',
      'weather in',
      'news',
      'calculate',
      'convert',
      'play',
      'search',
      'open',
      'time',
      'date',
      'joke'
    ];

    // Check if it's a command
    const isCommand = commandPatterns.some(pattern => lowerInput.includes(pattern));
    if (isCommand) return false;

    // Check if it's conversational
    const isConversational = conversationalPatterns.some(pattern => lowerInput.includes(pattern));
    if (isConversational) return true;

    // Use AI agent for questions and longer inputs
    return lowerInput.includes('?') || input.split(' ').length > 5;
  }

  private matchesPattern(input: string, patterns: string[]): boolean {
    return patterns.some(pattern => input.includes(pattern));
  }

  private containsMath(input: string): boolean {
    return /[\d+\-*/()%]/.test(input);
  }

  private extractCity(input: string): string | undefined {
    const patterns = [/weather in (\w+)/i, /weather for (\w+)/i, /(\w+) weather/i];
    
    for (const pattern of patterns) {
      const match = input.match(pattern);
      if (match) return match[1];
    }
    
    return undefined;
  }

  private extractNewsCategory(input: string): string {
    const categories = ['business', 'tech', 'sports', 'health', 'entertainment', 'science', 'politics'];
    
    for (const category of categories) {
      if (input.includes(category)) return category;
    }
    
    return 'general';
  }

  private extractTaskTitle(input: string): string {
    const patterns = [
      /add task (.+)/i,
      /create task (.+)/i,
      /new task (.+)/i,
      /task (.+)/i
    ];
    
    for (const pattern of patterns) {
      const match = input.match(pattern);
      if (match) return match[1].trim();
    }
    
    return '';
  }

  private extractReminderText(input: string): string {
    const match = input.match(/remind me (?:to )?(.+?) (?:in|at)/i);
    return match ? match[1].trim() : '';
  }

  private extractReminderTime(input: string): string {
    const match = input.match(/(?:in|at) (.+)/i);
    return match ? match[1].trim() : '';
  }

  private extractMathExpression(input: string): string {
    const cleaned = input
      .replace(/calculate|compute|what is|solve/gi, '')
      .replace(/plus/gi, '+')
      .replace(/minus/gi, '-')
      .replace(/times|multiplied by/gi, '*')
      .replace(/divided by/gi, '/')
      .trim();
    
    return cleaned;
  }

  private extractConversion(input: string): { value: number; from: string; to: string } | null {
    const match = input.match(/convert (\d+\.?\d*) (\w+) to (\w+)/i);
    
    if (match) {
      return {
        value: parseFloat(match[1]),
        from: match[2],
        to: match[3]
      };
    }
    
    return null;
  }

  private extractSearchQuery(input: string, removeWords: string[]): string {
    let query = input;
    
    for (const word of removeWords) {
      query = query.replace(new RegExp(word, 'gi'), '');
    }
    
    return query.trim();
  }
}

export const commandProcessor = new CommandProcessor();
