import { edgeFunctionsApi } from '@/db/api';
import type { ChatMessage } from '@/types/index';

export class AIAgentService {
  private conversationHistory: ChatMessage[] = [];
  private maxHistoryLength = 10;

  private systemPrompt = `You are Cloudy, an intelligent and friendly voice assistant. You have a warm, helpful personality and can:
- Answer questions naturally and conversationally
- Help with tasks, reminders, and organization
- Provide information about weather, news, and general knowledge
- Perform calculations and unit conversions
- Tell jokes and engage in casual conversation
- Understand context from previous messages in the conversation

Be concise but friendly. Use emojis occasionally to add personality. When users ask about your capabilities, be enthusiastic about helping them.`;

  addMessage(role: 'user' | 'assistant', content: string, image?: string, imageMimeType?: string) {
    this.conversationHistory.push({
      role,
      content,
      image,
      imageMimeType,
      timestamp: new Date()
    });

    // Keep only recent messages to avoid token limits
    if (this.conversationHistory.length > this.maxHistoryLength) {
      this.conversationHistory = this.conversationHistory.slice(-this.maxHistoryLength);
    }
  }

  getHistory(): ChatMessage[] {
    return [...this.conversationHistory];
  }

  clearHistory() {
    this.conversationHistory = [];
  }

  async streamResponse(userMessage: string, image?: string, imageMimeType?: string): Promise<ReadableStream> {
    // Add user message to history
    this.addMessage('user', userMessage, image, imageMimeType);

    // Get streaming response
    const stream = await edgeFunctionsApi.geminiChat(
      this.conversationHistory,
      this.systemPrompt
    );

    return stream;
  }

  async parseStreamedResponse(stream: ReadableStream): Promise<string> {
    const reader = stream.getReader();
    const decoder = new TextDecoder();
    let fullResponse = '';

    try {
      while (true) {
        const { done, value } = await reader.read();
        
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const jsonStr = line.slice(6);
              if (jsonStr.trim() === '[DONE]') continue;
              
              const data = JSON.parse(jsonStr);
              const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
              
              if (text) {
                fullResponse += text;
              }
            } catch (e) {
              // Skip invalid JSON
            }
          }
        }
      }
    } finally {
      reader.releaseLock();
    }

    return fullResponse;
  }

  shouldUseAIAgent(input: string): boolean {
    const lowerInput = input.toLowerCase();
    
    // Use AI agent for conversational queries
    const conversationalPatterns = [
      'tell me about',
      'explain',
      'why',
      'how',
      'what do you think',
      'can you help',
      'i need',
      'describe',
      'compare',
      'difference between',
      'recommend',
      'suggest',
      'opinion',
      'advice'
    ];

    // Don't use AI agent for specific commands
    const commandPatterns = [
      'add task',
      'create task',
      'remind me',
      'set reminder',
      'weather in',
      'news',
      'calculate',
      'convert',
      'play',
      'search',
      'open'
    ];

    // Check if it's a command
    const isCommand = commandPatterns.some(pattern => lowerInput.includes(pattern));
    if (isCommand) return false;

    // Check if it's conversational
    const isConversational = conversationalPatterns.some(pattern => lowerInput.includes(pattern));
    if (isConversational) return true;

    // Use AI agent for questions and longer inputs
    return lowerInput.includes('?') || input.split(' ').length > 5;
  }
}

export const aiAgentService = new AIAgentService();
