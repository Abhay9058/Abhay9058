// Calculator utility
export const calculator = {
  evaluate: (expression: string): string => {
    try {
      // Remove any non-mathematical characters for safety
      const sanitized = expression.replace(/[^0-9+\-*/().%\s]/g, '');
      
      // Use Function constructor for safe evaluation
      const result = Function(`'use strict'; return (${sanitized})`)();
      
      if (typeof result === 'number' && !isNaN(result)) {
        return result.toString();
      }
      
      return 'Invalid calculation';
    } catch (error) {
      return 'Error in calculation';
    }
  }
};

// Unit conversion utility
export const unitConverter = {
  convert: (value: number, fromUnit: string, toUnit: string): string => {
    const conversions: Record<string, Record<string, number>> = {
      // Length
      meter: { meter: 1, kilometer: 0.001, mile: 0.000621371, foot: 3.28084, inch: 39.3701 },
      kilometer: { meter: 1000, kilometer: 1, mile: 0.621371, foot: 3280.84, inch: 39370.1 },
      mile: { meter: 1609.34, kilometer: 1.60934, mile: 1, foot: 5280, inch: 63360 },
      foot: { meter: 0.3048, kilometer: 0.0003048, mile: 0.000189394, foot: 1, inch: 12 },
      inch: { meter: 0.0254, kilometer: 0.0000254, mile: 0.000015783, foot: 0.0833333, inch: 1 },
      
      // Weight
      kilogram: { kilogram: 1, gram: 1000, pound: 2.20462, ounce: 35.274 },
      gram: { kilogram: 0.001, gram: 1, pound: 0.00220462, ounce: 0.035274 },
      pound: { kilogram: 0.453592, gram: 453.592, pound: 1, ounce: 16 },
      ounce: { kilogram: 0.0283495, gram: 28.3495, pound: 0.0625, ounce: 1 },
      
      // Temperature (special handling)
      celsius: { celsius: 1, fahrenheit: 0, kelvin: 0 },
      fahrenheit: { celsius: 0, fahrenheit: 1, kelvin: 0 },
      kelvin: { celsius: 0, fahrenheit: 0, kelvin: 1 }
    };

    const from = fromUnit.toLowerCase();
    const to = toUnit.toLowerCase();

    // Special handling for temperature
    if (['celsius', 'fahrenheit', 'kelvin'].includes(from)) {
      if (from === 'celsius' && to === 'fahrenheit') {
        return ((value * 9/5) + 32).toFixed(2);
      }
      if (from === 'celsius' && to === 'kelvin') {
        return (value + 273.15).toFixed(2);
      }
      if (from === 'fahrenheit' && to === 'celsius') {
        return ((value - 32) * 5/9).toFixed(2);
      }
      if (from === 'fahrenheit' && to === 'kelvin') {
        return (((value - 32) * 5/9) + 273.15).toFixed(2);
      }
      if (from === 'kelvin' && to === 'celsius') {
        return (value - 273.15).toFixed(2);
      }
      if (from === 'kelvin' && to === 'fahrenheit') {
        return (((value - 273.15) * 9/5) + 32).toFixed(2);
      }
      if (from === to) {
        return value.toFixed(2);
      }
    }

    // Regular conversions
    if (conversions[from] && conversions[from][to]) {
      const result = value * conversions[from][to];
      return result.toFixed(4);
    }

    return 'Conversion not supported';
  },

  getSupportedUnits: (): string[] => {
    return [
      'meter', 'kilometer', 'mile', 'foot', 'inch',
      'kilogram', 'gram', 'pound', 'ounce',
      'celsius', 'fahrenheit', 'kelvin'
    ];
  }
};

// Time utility
export const timeUtils = {
  getCurrentTime: (): string => {
    const now = new Date();
    return now.toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true 
    });
  },

  getCurrentDate: (): string => {
    const now = new Date();
    return now.toLocaleDateString('en-US', { 
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  },

  getCurrentDateTime: (): string => {
    return `${timeUtils.getCurrentDate()} at ${timeUtils.getCurrentTime()}`;
  },

  parseReminderTime: (input: string): Date | null => {
    const now = new Date();
    const lowerInput = input.toLowerCase();

    // Handle relative times
    if (lowerInput.includes('minute')) {
      const minutes = parseInt(lowerInput.match(/\d+/)?.[0] || '0');
      return new Date(now.getTime() + minutes * 60000);
    }
    
    if (lowerInput.includes('hour')) {
      const hours = parseInt(lowerInput.match(/\d+/)?.[0] || '0');
      return new Date(now.getTime() + hours * 3600000);
    }

    if (lowerInput.includes('day')) {
      const days = parseInt(lowerInput.match(/\d+/)?.[0] || '0');
      return new Date(now.getTime() + days * 86400000);
    }

    // Try to parse as date string
    try {
      const parsed = new Date(input);
      if (!isNaN(parsed.getTime())) {
        return parsed;
      }
    } catch {
      return null;
    }

    return null;
  }
};

// Joke utility
export const jokeUtils = {
  getRandomJoke: (): string => {
    const jokes = [
      "Why don't scientists trust atoms? Because they make up everything!",
      "Why did the scarecrow win an award? He was outstanding in his field!",
      "Why don't eggs tell jokes? They'd crack each other up!",
      "What do you call a fake noodle? An impasta!",
      "Why did the bicycle fall over? Because it was two-tired!",
      "What do you call a bear with no teeth? A gummy bear!",
      "Why couldn't the bicycle stand up by itself? It was two tired!",
      "What did one wall say to the other wall? I'll meet you at the corner!",
      "Why don't skeletons fight each other? They don't have the guts!",
      "What do you call cheese that isn't yours? Nacho cheese!"
    ];
    
    return jokes[Math.floor(Math.random() * jokes.length)];
  }
};

// Wikipedia utility
export const wikipediaUtils = {
  search: async (query: string): Promise<string> => {
    try {
      const url = `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(query)}`;
      const response = await fetch(url);
      
      if (!response.ok) {
        return `I couldn't find information about "${query}" on Wikipedia.`;
      }
      
      const data = await response.json();
      return data.extract || `No summary available for "${query}".`;
    } catch (error) {
      return `Error searching Wikipedia: ${error instanceof Error ? error.message : 'Unknown error'}`;
    }
  }
};

// URL utilities
export const urlUtils = {
  openGoogle: (query?: string): void => {
    const url = query 
      ? `https://www.google.com/search?q=${encodeURIComponent(query)}`
      : 'https://www.google.com';
    window.open(url, '_blank');
  },

  openYouTube: (query?: string): void => {
    const url = query
      ? `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`
      : 'https://www.youtube.com';
    window.open(url, '_blank');
  }
};
