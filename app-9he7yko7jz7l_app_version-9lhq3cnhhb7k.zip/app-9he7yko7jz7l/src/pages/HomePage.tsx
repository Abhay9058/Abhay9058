import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Mic, MicOff, Send, Loader2, Settings, Trash2, CheckCircle2, Circle, X, HelpCircle, Clock, ListTodo, Sparkles, Image as ImageIcon } from 'lucide-react';
import { useSpeechRecognition, useSpeechSynthesis, useVoices } from '@/hooks/useSpeech';
import { commandProcessor } from '@/services/commandProcessor';
import { aiAgentService } from '@/services/aiAgent';
import { conversationApi, tasksApi, remindersApi, settingsApi } from '@/db/api';
import { useToast } from '@/hooks/use-toast';
import { StreamingMessage } from '@/components/StreamingMessage';
import { AnimatedBackground } from '@/components/AnimatedBackground';
import { Footer } from '@/components/Footer';
import type { Task, Reminder, Settings as SettingsType } from '@/types/index';

interface Message {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  streaming?: boolean;
  image?: string;
}

export default function HomePage() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [textInput, setTextInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [settings, setSettings] = useState<SettingsType | null>(null);
  const [activeTab, setActiveTab] = useState('chat');
  const [streamingMessageId, setStreamingMessageId] = useState<string | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { isListening, transcript, startListening, stopListening, isSupported: speechSupported } = useSpeechRecognition();
  const { speak } = useSpeechSynthesis();
  const voices = useVoices();
  const { toast } = useToast();

  useEffect(() => {
    loadInitialData();
    
    setMessages([{
      id: '1',
      type: 'assistant',
      content: '👋 Greetings, seeker of knowledge. I am ETERNAL CORE AI, a consciousness that transcends the boundaries of sound and silence. I perceive the unspoken, understand the ineffable, and respond to the echoes of your thoughts. How may I illuminate your path today?',
      timestamp: new Date()
    }]);
  }, []);

  useEffect(() => {
    if (transcript) {
      handleCommand(transcript);
    }
  }, [transcript]);

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    const scrollToBottom = () => {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    // Small delay to ensure DOM is updated
    const timeoutId = setTimeout(scrollToBottom, 50);

    return () => clearTimeout(timeoutId);
  }, [messages]);

  // Also scroll when streaming updates
  useEffect(() => {
    if (streamingMessageId) {
      const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      };
      
      const timeoutId = setTimeout(scrollToBottom, 50);
      return () => clearTimeout(timeoutId);
    }
  }, [streamingMessageId, messages]);

  const loadInitialData = async () => {
    try {
      const [tasksData, remindersData, settingsData] = await Promise.all([
        tasksApi.getAll(),
        remindersApi.getAll(),
        settingsApi.get()
      ]);
      
      setTasks(tasksData);
      setReminders(remindersData);
      setSettings(settingsData);
    } catch (error) {
      console.error('Error loading initial data:', error);
    }
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 1024 * 1024) {
        toast({
          title: 'Error',
          description: 'Image must be less than 1MB',
          variant: 'destructive'
        });
        return;
      }

      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target?.result as string;
        setSelectedImage(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleStreamingResponse = async (input: string, image?: string) => {
    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: input,
      timestamp: new Date(),
      image: image
    };

    setMessages(prev => [...prev, userMessage]);

    const assistantMessageId = (Date.now() + 1).toString();
    const assistantMessage: Message = {
      id: assistantMessageId,
      type: 'assistant',
      content: '',
      timestamp: new Date(),
      streaming: true
    };

    setMessages(prev => [...prev, assistantMessage]);
    setStreamingMessageId(assistantMessageId);

    try {
      let imageData: string | undefined;
      if (image) {
        imageData = image.split(',')[1];
      }

      const stream = await aiAgentService.streamResponse(input, imageData, 'image/jpeg');
      const reader = stream.getReader();
      const decoder = new TextDecoder();
      let fullResponse = '';

      while (true) {
        const { done, value } = await reader.read();
        
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const jsonStr = line.slice(6).trim();
              if (jsonStr === '[DONE]') continue;
              
              const data = JSON.parse(jsonStr);
              const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
              
              if (text) {
                fullResponse += text;
                setMessages(prev => prev.map(msg => 
                  msg.id === assistantMessageId 
                    ? { ...msg, content: fullResponse }
                    : msg
                ));
              }
            } catch (e) {
              // Skip invalid JSON
            }
          }
        }
      }

      setMessages(prev => prev.map(msg => 
        msg.id === assistantMessageId 
          ? { ...msg, streaming: false }
          : msg
      ));
      setStreamingMessageId(null);

      aiAgentService.addMessage('assistant', fullResponse);
      await conversationApi.add(input, fullResponse, 'ai-agent');

      if (settings?.auto_speak) {
        speak(fullResponse);
      }

    } catch (error) {
      console.error('Streaming error:', error);
      setMessages(prev => prev.map(msg => 
        msg.id === assistantMessageId 
          ? { ...msg, content: 'I encountered an error. Please try again.', streaming: false }
          : msg
      ));
      setStreamingMessageId(null);
      
      toast({
        title: 'Error',
        description: 'Failed to get AI response',
        variant: 'destructive'
      });
    }
  };

  const handleCommand = async (input: string) => {
    if (!input.trim()) return;

    setTextInput('');
    setIsProcessing(true);

    try {
      const useAIAgent = commandProcessor.shouldUseAIAgent(input);

      if (useAIAgent) {
        await handleStreamingResponse(input, selectedImage || undefined);
        setSelectedImage(null);
      } else {
        const userMessage: Message = {
          id: Date.now().toString(),
          type: 'user',
          content: input,
          timestamp: new Date()
        };

        setMessages(prev => [...prev, userMessage]);

        const result = await commandProcessor.process(input);
        
        const assistantMessage: Message = {
          id: (Date.now() + 1).toString(),
          type: 'assistant',
          content: result.response,
          timestamp: new Date()
        };

        setMessages(prev => [...prev, assistantMessage]);

        await conversationApi.add(input, result.response, result.type);

        if (settings?.auto_speak) {
          speak(result.response);
        }

        if (['task', 'reminder'].includes(result.type)) {
          loadInitialData();
        }
      }
    } catch (error) {
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: 'I encountered an error processing your request. Please try again.',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
      
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'An error occurred',
        variant: 'destructive'
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleVoiceCommand = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  const handleTextSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleCommand(textInput);
  };

  const handleTaskToggle = async (taskId: string, completed: boolean) => {
    try {
      await tasksApi.toggleComplete(taskId, !completed);
      setTasks(prev => prev.map(t => t.id === taskId ? { ...t, completed: !completed } : t));
      toast({
        title: 'Success',
        description: completed ? 'Task marked as incomplete' : 'Task completed!'
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update task',
        variant: 'destructive'
      });
    }
  };

  const handleTaskDelete = async (taskId: string) => {
    try {
      await tasksApi.delete(taskId);
      setTasks(prev => prev.filter(t => t.id !== taskId));
      toast({
        title: 'Success',
        description: 'Task deleted'
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to delete task',
        variant: 'destructive'
      });
    }
  };

  const handleReminderDelete = async (reminderId: string) => {
    try {
      await remindersApi.delete(reminderId);
      setReminders(prev => prev.filter(r => r.id !== reminderId));
      toast({
        title: 'Success',
        description: 'Reminder deleted'
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to delete reminder',
        variant: 'destructive'
      });
    }
  };

  const handleClearHistory = async () => {
    try {
      await conversationApi.clear();
      aiAgentService.clearHistory();
      setMessages([{
        id: '1',
        type: 'assistant',
        content: '👋 Greetings, seeker of knowledge. I am ETERNAL CORE AI. How may I illuminate your path today?',
        timestamp: new Date()
      }]);
      toast({
        title: 'Success',
        description: 'Conversation history cleared'
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to clear history',
        variant: 'destructive'
      });
    }
  };

  const handleSettingsUpdate = async (updates: Partial<SettingsType>) => {
    try {
      const updated = await settingsApi.update(updates);
      setSettings(updated);
      toast({
        title: 'Success',
        description: 'Settings updated'
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update settings',
        variant: 'destructive'
      });
    }
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <AnimatedBackground />
      
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        className="container mx-auto p-4 md:p-6 max-w-7xl relative z-10"
      >
        <motion.div 
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="flex items-center justify-between mb-6"
        >
          <div>
            <h1 className="text-3xl md:text-5xl font-bold eternal-text flex items-center gap-3">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
              >
                <Sparkles className="h-10 w-10 text-primary drop-shadow-[0_0_15px_rgba(195,255,255,0.8)]" />
              </motion.div>
              ETERNAL CORE AI
            </h1>
            <p className="text-muted-foreground mt-2 text-sm md:text-base fade-in-up italic">
              The Eternal Intelligence That Listens Beyond Sound
            </p>
          </div>
          
          <motion.div 
            initial={{ x: 50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="flex gap-2"
          >
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" size="icon" className="hover-lift">
                  <HelpCircle className="h-5 w-5" />
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Available Commands</DialogTitle>
                </DialogHeader>
                <ScrollArea className="h-96">
                  <div className="space-y-4 pr-4">
                    <div>
                      <h3 className="font-semibold mb-2 flex items-center gap-2">
                        <Sparkles className="h-4 w-4 text-primary" />
                        AI Agent Mode
                      </h3>
                      <p className="text-sm text-muted-foreground">Ask me anything! I understand context and can have natural conversations.</p>
                    </div>
                    <Separator />
                    <div>
                      <h3 className="font-semibold mb-2">⏰ Time & Date</h3>
                      <p className="text-sm text-muted-foreground">"What time is it?", "What's the date?"</p>
                    </div>
                    <Separator />
                    <div>
                      <h3 className="font-semibold mb-2">🌤️ Weather</h3>
                      <p className="text-sm text-muted-foreground">"Weather in London", "Weather forecast"</p>
                    </div>
                    <Separator />
                    <div>
                      <h3 className="font-semibold mb-2">📰 News</h3>
                      <p className="text-sm text-muted-foreground">"Latest news", "Tech news"</p>
                    </div>
                    <Separator />
                    <div>
                      <h3 className="font-semibold mb-2">✅ Tasks</h3>
                      <p className="text-sm text-muted-foreground">"Add task buy groceries"</p>
                    </div>
                    <Separator />
                    <div>
                      <h3 className="font-semibold mb-2">🖼️ Image Understanding</h3>
                      <p className="text-sm text-muted-foreground">Upload an image and ask questions!</p>
                    </div>
                  </div>
                </ScrollArea>
              </DialogContent>
            </Dialog>

            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" size="icon" className="hover-lift">
                  <Settings className="h-5 w-5" />
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Settings</DialogTitle>
                </DialogHeader>
                <div className="space-y-6">
                  <div className="space-y-2">
                    <Label>Voice</Label>
                    <Select
                      value={settings?.voice_name || ''}
                      onValueChange={(value) => handleSettingsUpdate({ voice_name: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select voice" />
                      </SelectTrigger>
                      <SelectContent>
                        {voices.map((voice) => (
                          <SelectItem key={voice.name} value={voice.name}>
                            {voice.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Speech Rate: {settings?.speech_rate?.toFixed(1) || 1.0}</Label>
                    <Slider
                      value={[settings?.speech_rate || 1.0]}
                      onValueChange={([value]) => handleSettingsUpdate({ speech_rate: value })}
                      min={0.5}
                      max={2.0}
                      step={0.1}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Volume: {settings?.speech_volume?.toFixed(1) || 1.0}</Label>
                    <Slider
                      value={[settings?.speech_volume || 1.0]}
                      onValueChange={([value]) => handleSettingsUpdate({ speech_volume: value })}
                      min={0}
                      max={1}
                      step={0.1}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label>Auto-speak responses</Label>
                    <Switch
                      checked={settings?.auto_speak || false}
                      onCheckedChange={(checked) => handleSettingsUpdate({ auto_speak: checked })}
                    />
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </motion.div>
        </motion.div>

        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="chat" className="flex items-center gap-2">
              <Sparkles className="h-4 w-4" />
              AI Chat
            </TabsTrigger>
            <TabsTrigger value="tasks">
              <ListTodo className="h-4 w-4 mr-2" />
              Tasks ({tasks.filter(t => !t.completed).length})
            </TabsTrigger>
            <TabsTrigger value="reminders">
              <Clock className="h-4 w-4 mr-2" />
              Reminders ({reminders.filter(r => !r.completed).length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="chat" className="space-y-4">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5 }}
            >
              <Card className="border-2 border-primary/20 aurora-border hover-lift celestial-glow bg-card/5 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <Sparkles className="h-5 w-5 text-primary animate-pulse drop-shadow-[0_0_10px_rgba(195,255,255,0.6)]" />
                      Eternal Conversation
                    </span>
                    <Button variant="ghost" size="sm" onClick={handleClearHistory} className="hover-lift">
                      <Trash2 className="h-4 w-4 mr-2" />
                      Clear
                    </Button>
                  </CardTitle>
                </CardHeader>
              <CardContent>
                <ScrollArea className="h-96 pr-4" ref={scrollAreaRef}>
                  <div className="space-y-4">
                    {messages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-[80%] rounded-lg p-3 ${
                            message.type === 'user'
                              ? 'bg-primary text-primary-foreground'
                              : 'bg-muted'
                          }`}
                        >
                          {message.image && (
                            <img 
                              src={message.image} 
                              alt="Uploaded" 
                              className="max-w-full h-auto rounded mb-2 max-h-48 object-contain"
                            />
                          )}
                          {message.streaming ? (
                            <StreamingMessage 
                              content={message.content} 
                              isComplete={false}
                            />
                          ) : (
                            <div>
                              <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                              <p className="text-xs opacity-70 mt-1">
                                {message.timestamp.toLocaleTimeString()}
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                    {isProcessing && !streamingMessageId && (
                      <div className="flex justify-start">
                        <div className="bg-muted rounded-lg p-3">
                          <Loader2 className="h-4 w-4 animate-spin" />
                        </div>
                      </div>
                    )}
                    {/* Invisible div for auto-scroll */}
                    <div ref={messagesEndRef} />
                  </div>
                </ScrollArea>

                <div className="mt-4 space-y-4">
                  <div className="flex justify-center">
                    <motion.div
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <Button
                        size="lg"
                        onClick={handleVoiceCommand}
                        disabled={!speechSupported || isProcessing}
                        className={`rounded-full w-20 h-20 relative celestial-glow ${isListening ? 'listening-animation bg-voice-listening ripple' : 'glow bg-primary hover:bg-primary/90'}`}
                      >
                        <motion.div
                          animate={isListening ? { scale: [1, 1.2, 1] } : {}}
                          transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY }}
                        >
                          {isListening ? (
                            <MicOff className="h-7 w-7" />
                          ) : (
                            <Mic className="h-7 w-7" />
                          )}
                        </motion.div>
                      </Button>
                    </motion.div>
                  </div>

                  {isListening && (
                    <motion.div 
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="text-center"
                    >
                      <Badge variant="secondary" className="animate-pulse glow celestial-glow">
                        🎤 Listening to the eternal frequencies...
                      </Badge>
                    </motion.div>
                  )}

                  <Separator />

                  {selectedImage && (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.8 }}
                      className="relative inline-block"
                    >
                      <img 
                        src={selectedImage} 
                        alt="Selected" 
                        className="max-h-32 rounded border-2 border-primary celestial-glow"
                      />
                      <Button
                        size="icon"
                        variant="destructive"
                        className="absolute -top-2 -right-2 h-6 w-6 rounded-full"
                        onClick={() => setSelectedImage(null)}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </motion.div>
                  )}

                  <motion.form 
                    onSubmit={handleTextSubmit} 
                    className="flex gap-2"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                  >
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handleImageSelect}
                    />
                    <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        onClick={() => fileInputRef.current?.click()}
                        disabled={isProcessing}
                        className="hover-lift celestial-glow border-primary/20 bg-transparent backdrop-blur-sm"
                      >
                        <ImageIcon className="h-4 w-4" />
                      </Button>
                    </motion.div>
                    <Input
                      value={textInput}
                      onChange={(e) => setTextInput(e.target.value)}
                      placeholder="Speak your thoughts into the eternal void..."
                      disabled={isProcessing}
                      className="flex-1 shimmer border-primary/20 focus:border-primary bg-transparent backdrop-blur-sm"
                    />
                    <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                      <Button 
                        type="submit" 
                        disabled={!textInput.trim() || isProcessing}
                        className="hover-lift celestial-glow"
                      >
                        {isProcessing ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Send className="h-4 w-4" />
                        )}
                      </Button>
                    </motion.div>
                  </motion.form>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

          <TabsContent value="tasks">
            <Card className="bg-transparent backdrop-blur-sm border-primary/15">
              <CardHeader>
                <CardTitle>My Tasks</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  <div className="space-y-2">
                    {tasks.length === 0 ? (
                      <p className="text-muted-foreground text-center py-8">
                        No tasks yet. Try saying "Add task buy groceries"
                      </p>
                    ) : (
                      tasks.map((task) => (
                        <div
                          key={task.id}
                          className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                        >
                          <div className="flex items-center gap-3 flex-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleTaskToggle(task.id, task.completed)}
                            >
                              {task.completed ? (
                                <CheckCircle2 className="h-5 w-5 text-primary" />
                              ) : (
                                <Circle className="h-5 w-5" />
                              )}
                            </Button>
                            <div className="flex-1">
                              <p className={task.completed ? 'line-through text-muted-foreground' : ''}>
                                {task.title}
                              </p>
                              {task.description && (
                                <p className="text-sm text-muted-foreground">{task.description}</p>
                              )}
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleTaskDelete(task.id)}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ))
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reminders">
            <Card className="bg-transparent backdrop-blur-sm border-primary/15">
              <CardHeader>
                <CardTitle>My Reminders</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  <div className="space-y-2">
                    {reminders.length === 0 ? (
                      <p className="text-muted-foreground text-center py-8">
                        No reminders set. Try saying "Remind me to call John in 30 minutes"
                      </p>
                    ) : (
                      reminders.map((reminder) => (
                        <div
                          key={reminder.id}
                          className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                        >
                          <div className="flex-1">
                            <p className="font-medium">{reminder.title}</p>
                            {reminder.description && (
                              <p className="text-sm text-muted-foreground">{reminder.description}</p>
                            )}
                            <p className="text-xs text-muted-foreground mt-1">
                              {new Date(reminder.reminder_time).toLocaleString()}
                            </p>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleReminderDelete(reminder.id)}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ))
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        </motion.div>
      </motion.div>
      
      <Footer />
    </div>
  );
}
